# patterns.py
# 华山八字智能模式识别系统 (Patterns Analyzer)
from huashan_core import TIANGAN, DIZHI, WUXING_TG, WUXING_DZ, YINYANG_TG, YINYANG_DZ
from huashan_core import get_shishen_stem

def detect_same_material(bazi_dict):
    """
    1. 同材异路识别 (Same-Material Detection)
    统计原局 8 个字中，每个字出现的次数。
    2次：[强化]，3次：[波折/逢三即变]，4次：[偏枯/物极必反]
    """
    counts = {}
    
    # 提取8个字
    chars = [
        bazi_dict["Y"][0], bazi_dict["Y"][1],
        bazi_dict["M"][0], bazi_dict["M"][1],
        bazi_dict["D"][0], bazi_dict["D"][1],
        bazi_dict["H"][0], bazi_dict["H"][1]
    ]
    
    for c in chars:
        counts[c] = counts.get(c, 0) + 1
        
    res = []
    level_map = {2: "强化", 3: "波折/逢三必变", 4: "物极必反"}
    note_map = {
        2: "能量加倍，需注意该五行或十神主导的领域。",
        3: "极高优先级的预警信号，凡事波折易变。",
        4: "偏枯之兆，极端状态，福祸相依。"
    }
    
    for char, count in counts.items():
        if count >= 2:
            lv = count if count <= 4 else 4
            res.append({
                "Char": char,
                "Count": count,
                "Level": level_map[lv],
                "Note": note_map[lv]
            })
            
    return res

def check_tian_ke_di_chong(tg1, dz1, tg2, dz2):
    """检测两柱是否天克地冲"""
    # 天干相克：0:同 1:我生 2:我克 3:克我 4:生我
    wx_map = {"木": 0, "火": 1, "土": 2, "金": 3, "水": 4}
    tg1_wx = wx_map[WUXING_TG[TIANGAN.index(tg1)]]
    tg2_wx = wx_map[WUXING_TG[TIANGAN.index(tg2)]]
    tg_rel = (tg2_wx - tg1_wx) % 5
    is_tg_ke = (tg_rel == 2 or tg_rel == 3) # 互相克
    
    # 地支相冲：距离为6
    dz1_idx = DIZHI.index(dz1)
    dz2_idx = DIZHI.index(dz2)
    is_dz_chong = abs(dz1_idx - dz2_idx) == 6
    
    return is_tg_ke and is_dz_chong

def check_tian_he_di_he(tg1, dz1, tg2, dz2):
    """检测天地双合"""
    # 天干五合：甲己合(0,5), 乙庚合(1,6), 丙辛(2,7), 丁壬(3,8), 戊癸(4,9)
    tg1_idx = TIANGAN.index(tg1)
    tg2_idx = TIANGAN.index(tg2)
    is_tg_he = abs(tg1_idx - tg2_idx) == 5
    
    # 地支六合：子丑(0,1), 寅亥(2,11), 卯戌(3,10), 辰酉(4,9), 巳申(5,8), 午未(6,7)
    he_pairs = [{0,1}, {2,11}, {3,10}, {4,9}, {5,8}, {6,7}]
    is_dz_he = {DIZHI.index(dz1), DIZHI.index(dz2)} in he_pairs
    
    return is_tg_he and is_dz_he
    
def check_tian_chong_di_chong(tg1, dz1, tg2, dz2):
    """天地双冲：天干只论克（甲戊、乙己等或庚甲、辛乙相冲），这里用严格七杀对冲(距离4或6 -> 实际为6，甲庚冲，乙辛冲，壬丙冲，癸丁冲)"""
    tg1_idx = TIANGAN.index(tg1)
    tg2_idx = TIANGAN.index(tg2)
    is_tg_chong = abs(tg1_idx - tg2_idx) in [4, 6] # 甲0，庚6。乙1，辛7。丙2，壬8。
    
    dz1_idx = DIZHI.index(dz1)
    dz2_idx = DIZHI.index(dz2)
    is_dz_chong = abs(dz1_idx - dz2_idx) == 6
    return is_tg_chong and is_dz_chong
    

def detect_special_combinations(bazi_dict):
    """
    2. 六大特殊吉凶组合探测
    原局四柱两两比对，查找伏吟、相冲、相合。
    （岁运并临等涉及流年，应放在外部排盘引擎组装时判别，此处先测原局）
    """
    res = []
    pillars = [
        ("年柱", bazi_dict["Y"]),
        ("月柱", bazi_dict["M"]),
        ("日柱", bazi_dict["D"]),
        ("时柱", bazi_dict["H"])
    ]
    
    for i in range(len(pillars)):
        for j in range(i + 1, len(pillars)):
            n1, p1 = pillars[i]
            n2, p2 = pillars[j]
            tg1, dz1 = p1[0], p1[1]
            tg2, dz2 = p2[0], p2[1]
            
            # 伏吟 (同干同支)
            if tg1 == tg2 and dz1 == dz2:
                res.append({
                    "Type": "伏吟",
                    "Pillars": [f"{n1}{tg1}{dz1}", f"{n2}{tg2}{dz2}"],
                    "Impact": f"{n1}与{n2}能量重叠，所辖宫位人事易生停滞或反覆。"
                })
            
            # 天地相合
            if check_tian_he_di_he(tg1, dz1, tg2, dz2):
                res.append({
                    "Type": "天地双合",
                    "Pillars": [f"{n1}{tg1}{dz1}", f"{n2}{tg2}{dz2}"],
                    "Impact": f"干支皆合，彼此羁绊极深，吉时阻碍化解，凶时纠缠难清。"
                })
                
            # 天克地冲
            if check_tian_ke_di_chong(tg1, dz1, tg2, dz2):
                res.append({
                    "Type": "天克地冲",
                    "Pillars": [f"{n1}{tg1}{dz1}", f"{n2}{tg2}{dz2}"],
                    "Impact": f"高危预警！干克支冲，根基动摇，此两柱管核之期限易有动荡与突变！"
                })
                
            # 天地双冲 (若没触发天克地冲)
            elif check_tian_chong_di_chong(tg1, dz1, tg2, dz2):
                 res.append({
                    "Type": "天地双冲",
                    "Pillars": [f"{n1}{tg1}{dz1}", f"{n2}{tg2}{dz2}"],
                    "Impact": f"极度对立冲克，如冰火难容，大起大落之象。"
                })
                
    return res

def decode_camps(dm, bazi_dict):
    """
    3. 十神阵营解码 (The Six Camps)
    获取原局透干的最强十神组合，归纳“生钱/谋事”阵营。
    （为简化，提取年月时的虚透十神进行偏正匹配组合）
    """
    stems = [bazi_dict["Y"][0], bazi_dict["M"][0], bazi_dict["H"][0]]
    shishens = [get_shishen_stem(dm, s) for s in stems]
    
    # 将包含的十神去重
    ss_set = set(shishens)
    
    # 建立简单的阵营推断字典 (这部分可以非常精细，这里落实用户要求的示例结构)
    # 偏包含：偏财，七杀，枭神，伤官，劫财
    # 正包含：正财，正官，正印，食神，比肩
    pian_list = {"偏财", "七杀", "枭神", "伤官", "劫财"}
    zheng_list = {"正财", "正官", "正印", "食神", "比肩"}
    
    current_pians = ss_set.intersection(pian_list)
    current_zhengs = ss_set.intersection(zheng_list)
    
    if len(current_pians) > 0 and len(current_zhengs) > 0:
        val1 = list(current_pians)[0]
        val2 = list(current_zhengs)[0]
        primary = f"偏配正 ({val1} 共存 {val2})"
        if "伤官" in current_pians and "正财" in current_zhengs:
             camp = "偏配正生 (伤官生正财)"
             desc = "极致技术换取稳健收益，严禁投机"
        elif "七杀" in current_pians and "正印" in current_zhengs:
             camp = "杀印相生 (异路正管)"
             desc = "以铁腕手段进行稳健治理，适合兵变或力挽狂澜"
        else:
             camp = primary
             desc = "阴阳手段交错，既有投机成分亦祈求稳健收官"
             
    elif len(current_pians) > 0:
        val1 = list(current_pians)[0]
        val2 = list(current_pians)[1] if len(current_pians) > 1 else val1
        camp = f"纯偏配 ({val1} 与 {val2})"
        if "七杀" in current_pians and "枭神" in current_pians:
            desc = "偏配偏生 - 异路博弈，游走边缘地带，非传统路线发家"
        else:
            desc = "极致的偏星生态，为人偏激、投机、暴利与高风险并存"
            
    elif len(current_zhengs) > 0:
        val1 = list(current_zhengs)[0]
        val2 = list(current_zhengs)[1] if len(current_zhengs) > 1 else val1
        camp = f"纯正配 ({val1} 与 {val2})"
        if "正官" in current_zhengs and "正印" in current_zhengs:
             desc = "正配正生 - 稳健管理，名门正道，依靠规章体制与信誉谋求发展"
        else:
             desc = "极度稳健的守成派，按部就班，难有奇险暴富，但底盘扎实"
    else:
        camp = "中允平庸"
        desc = "未受强金化木等明显组合影响，平淡度日"
        
    return {
        "Primary": camp,
        "Description": desc
    }
    
def generate_patterns(dm_stem, bazi_dict):
    """打包调用三个识别模块"""
    return {
        "RepetitionScan": detect_same_material(bazi_dict),
        "Combinations": detect_special_combinations(bazi_dict),
        "Camps": decode_camps(dm_stem, bazi_dict)
    }
