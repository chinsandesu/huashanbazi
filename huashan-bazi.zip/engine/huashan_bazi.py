# huashan_bazi.py
import argparse
import datetime
import yaml
import json
import sxtwl
from huashan_core import *
from lifecycle import *
from patterns import generate_patterns

def parse_time_str(date_str, time_str):
    if not date_str:
        now = datetime.datetime.now()
        y, m, d = now.year, now.month, now.day
    else:
        y, m, d = map(int, date_str.split("-"))
        
    if not time_str:
        now = datetime.datetime.now()
        h, min_ = now.hour, now.minute
    else:
        h, min_ = map(int, time_str.split(":"))
        
    return datetime.datetime(y, m, d, h, min_)

def get_base_bazi(dt):
    # sxtwl 从太阳历获取当前干支
    day = sxtwl.fromSolar(dt.year, dt.month, dt.day)
    
    y_gz = day.getYearGZ()
    m_gz = day.getMonthGZ()
    d_gz = day.getDayGZ()
    
    # 时辰推算 (华山自带五鼠遁，避免系统差异)
    zhi_idx = (dt.hour + 1) // 2 % 12
    base_tg = [0, 2, 4, 6, 8]  # 甲己0, 乙庚2, 丙辛4, 丁壬6, 戊癸8
    tg_idx = (base_tg[d_gz.tg % 5] + zhi_idx) % 10
    
    bazi = {
        "Y": (TIANGAN[y_gz.tg], DIZHI[y_gz.dz]),
        "M": (TIANGAN[m_gz.tg], DIZHI[m_gz.dz]),
        "D": (TIANGAN[d_gz.tg], DIZHI[d_gz.dz]),
        "H": (TIANGAN[tg_idx], DIZHI[zhi_idx])
    }
    return day, bazi

def _format_stem(dm, stem):
    return [stem, get_shishen_stem(dm, stem)]

def _get_jieqi_dates(y, m, d):
    """通过sxtwl寻找最近的上一个和下一个节气（用于大运）"""
    cur_solar = sxtwl.fromSolar(y, m, d)
    
    # 向前找上一个"节"（奇数索引如立春, 惊蛰）
    prev_j = cur_solar
    while True:
        if prev_j.hasJieQi() and prev_j.getJieQi() % 2 == 1:
            break
        prev_j = sxtwl.fromSolar(prev_j.getSolarYear(), prev_j.getSolarMonth(), prev_j.getSolarDay()-1 if prev_j.getSolarDay()>1 else 1) # simple fallback
        # 实际更优解：按儒略日减
        jd = cur_solar.getJD() - 1
        # 但 sxtwl 的 getJD 不是互逆的，简单的线性回滚
        # 这里仅为示范大运逻辑占位，后续可精修
        break
    
    # 向后找
    next_j = cur_solar
    while True:
        if next_j.hasJieQi() and next_j.getJieQi() % 2 == 1:
            break
        next_j = sxtwl.fromSolar(next_j.getSolarYear(), next_j.getSolarMonth(), next_j.getSolarDay()+1 if next_j.getSolarDay()<28 else 28)
        # 精确历推以后再做，当前先返回同日应对CLI通断
        break
        
    return datetime.datetime(y,m,d), datetime.datetime(y,m,d)


def run_bazi_engine(dt, gender, target_year, out_format="yaml"):
    s_day, bazi = get_base_bazi(dt)
    dm = bazi["D"][0] # 日主
    
    # 基础四柱明字五行
    all_stems = [bazi["Y"][0], bazi["M"][0], bazi["D"][0], bazi["H"][0]]
    all_branches = [bazi["Y"][1], bazi["M"][1], bazi["D"][1], bazi["H"][1]]
    
    stats = {"Wood":0, "Fire":0, "Earth":0, "Metal":0, "Water":0}
    wx_eng = {"木":"Wood", "火":"Fire", "土":"Earth", "金":"Metal", "水":"Water"}
    
    for tg in all_stems:
        stats[wx_eng[WUXING_TG[TIANGAN.index(tg)]]] += 1
    for dz in all_branches:
        stats[wx_eng[WUXING_DZ[DIZHI.index(dz)]]] += 1
        
    res = {
        "Meta": {
            "SolarTime": dt.strftime("%Y-%m-%d %H:%M"),
            "Gender": gender.upper()
        },
        "Bazi": {
            "DayMaster": dm,
            "Year": {
                "Stem": _format_stem(dm, bazi["Y"][0]),
                "Branch": bazi["Y"][1],
                "Shishen": get_shishen_branch(dm, bazi["Y"][1]),
                "NaYin": get_nayin(bazi["Y"][0], bazi["Y"][1]),
                "Stars": get_shensha(dm, bazi["Y"][1], is_year=True, year_branch=bazi["Y"][1], day_branch=bazi["D"][1], month_branch=bazi["M"][1]),
                "LifeStage": get_life_stage(dm, bazi["Y"][1])
            },
            "Month": {
                "Stem": _format_stem(dm, bazi["M"][0]),
                "Branch": bazi["M"][1],
                "Shishen": get_shishen_branch(dm, bazi["M"][1]),
                "NaYin": get_nayin(bazi["M"][0], bazi["M"][1]),
                "Stars": get_shensha(dm, bazi["M"][1], is_month=True, year_branch=bazi["Y"][1], day_branch=bazi["D"][1], month_branch=bazi["M"][1]),
                "LifeStage": get_life_stage(dm, bazi["M"][1])
            },
            "Day": {
                "Stem": _format_stem(dm, bazi["D"][0]),
                "Branch": bazi["D"][1],
                "Shishen": get_shishen_branch(dm, bazi["D"][1]),
                "NaYin": get_nayin(bazi["D"][0], bazi["D"][1]),
                "Stars": get_shensha(dm, bazi["D"][1], is_day=True, year_branch=bazi["Y"][1], day_branch=bazi["D"][1], month_branch=bazi["M"][1]),
                "LifeStage": get_life_stage(dm, bazi["D"][1])
            },
            "Hour": {
                "Stem": _format_stem(dm, bazi["H"][0]),
                "Branch": bazi["H"][1],
                "Shishen": get_shishen_branch(dm, bazi["H"][1]),
                "NaYin": get_nayin(bazi["H"][0], bazi["H"][1]),
                "Stars": get_shensha(dm, bazi["H"][1], year_branch=bazi["Y"][1], day_branch=bazi["D"][1], month_branch=bazi["M"][1]),
                "LifeStage": get_life_stage(dm, bazi["H"][1])
            }
        },
        "HiddenStems": [
            {"Branch": bazi["Y"][1], "Contains": [[s["stem"], s["shishen"]] for s in get_hidden_stems(dm, bazi["Y"][1])]},
            {"Branch": bazi["M"][1], "Contains": [[s["stem"], s["shishen"]] for s in get_hidden_stems(dm, bazi["M"][1])]},
            {"Branch": bazi["D"][1], "Contains": [[s["stem"], s["shishen"]] for s in get_hidden_stems(dm, bazi["D"][1])]},
            {"Branch": bazi["H"][1], "Contains": [[s["stem"], s["shishen"]] for s in get_hidden_stems(dm, bazi["H"][1])]}
        ],
        "XunKong": get_xunkong(bazi["D"][0], bazi["D"][1]),
        "ElementStats": stats,
        "Patterns": generate_patterns(dm, bazi),
        "LifeCycle": {
             "DaYun": {
                 "Direction": "Forward" if get_yun_direction(bazi["Y"][0], gender) == 1 else "Backward",
                 "StartAge": 0.0 # TODO: 节气绝对时间差计算
             },
             "CurrentYearAnalysis": analyze_current_year(dt.year, dt, bazi["H"][0], bazi["H"][1], bazi["Y"][0], gender),
             "DaYunMap": get_dayun_map(bazi["M"][0], bazi["M"][1], 1 if get_yun_direction(bazi["Y"][0], gender) == 1 else -1, 0.0, dt.year)
        }
    }
    
    if out_format == "json":
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        print(yaml.dump(res, allow_unicode=True, sort_keys=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='华山八字底座算力系统')
    parser.add_argument('-d', '--date', type=str, help='日期 YYYY-MM-DD', default="")
    parser.add_argument('-t', '--time', type=str, help='时间 HH:MM', default="")
    parser.add_argument('-g', '--gender', type=str, choices=['M', 'F', 'm', 'f'], required=True, help='性别(M/F)')
    parser.add_argument('-y', '--target-year', type=int, help='需要分析的流年年份 (如 2026)', default=None)
    parser.add_argument('--format', type=str, choices=['json', 'yaml'], default='yaml', help='输出格式')
    
    args = parser.parse_args()
    dt = parse_time_str(args.date, args.time)
    
    # 支持命令行参数覆写分析的目标年份，默认看被测者当年(或系统当前年)
    target_year = args.target_year if args.target_year else datetime.datetime.now().year
    
    run_bazi_engine(dt, args.gender.upper(), target_year, args.format)
