# huashan_core.py
# 纯函数设计的华山派命理心法算力层

# 基础常量区 (Base Constants)
TIANGAN = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"]
DIZHI = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"]

# 五行常量
WUXING_TG = ["木", "木", "火", "火", "土", "土", "金", "金", "水", "水"]
WUXING_DZ = ["水", "土", "木", "木", "土", "火", "火", "土", "金", "金", "土", "水"]

# 物理阴阳（子、午回归阳性；亥、巳归阴性）
# 阳=1, 阴=0
YINYANG_TG = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0]
YINYANG_DZ = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0] # 子是1，亥是0；寅卯辰巳午未... 对应 1,0,1,0,1,0...

# === 华山修正版核心藏干 ===
# 抛弃传统杂气，纯净的阴阳对位归宗
HUASHAN_CANGGAN = {
    "子": ["癸"],
    "丑": ["癸", "辛", "己"],
    "寅": ["甲", "丙", "己"],     # 纠偏：传统有戊无己
    "卯": ["乙"],
    "辰": ["癸", "乙", "戊"],
    "巳": ["丙", "庚", "戊"],
    "午": ["丁"],               # 纠偏：独留丁
    "未": ["丁", "乙", "己"],
    "申": ["庚", "壬", "己"],     # 纠偏：变戊为己
    "酉": ["辛"],
    "戌": ["丁", "辛", "戊"],
    "亥": ["壬", "甲", "戊"]
}


def _get_element_rel(dm_idx, target_idx, is_stem=True):
    """
    底层五行生克推导 (基础为天干)
    M克T -> 我克
    T克M -> 克我
    M生T -> 我生
    T生M -> 生我
    M同T -> 同我
    """
    # 转五行索引: 木0, 火1, 土2, 金3, 水4
    wx_map = {"木": 0, "火": 1, "土": 2, "金": 3, "水": 4}
    dm_wx = wx_map[WUXING_TG[dm_idx]]
    target_wx = wx_map[WUXING_TG[target_idx]] if is_stem else wx_map[WUXING_DZ[target_idx]]
    
    # 距离: (target - dm) % 5
    # 0=同我, 1=我生, 2=我克, 3=克我, 4=生我
    return (target_wx - dm_wx) % 5

# --- [ 十神生成系统 ] ---

def get_shishen_stem(dm_char, target_char):
    """
    华山天干（虚）十神生成矩阵 (The Stem Matrix)
    核心修正：我克者，同性正财，异性偏财
    """
    dm_idx = TIANGAN.index(dm_char)
    target_idx = TIANGAN.index(target_char)
    
    same_yinyang = (YINYANG_TG[dm_idx] == YINYANG_TG[target_idx])
    rel = _get_element_rel(dm_idx, target_idx, is_stem=True)
    
    if rel == 0: # 同我
        return "比肩" if same_yinyang else "劫财"
    elif rel == 1: # 我生
        return "食神" if same_yinyang else "伤官"
    elif rel == 2: # 我克 (华山正偏财重构)
        return "正财" if same_yinyang else "偏财"
    elif rel == 3: # 克我
        return "七杀" if same_yinyang else "正官"
    elif rel == 4: # 生我
        return "枭神" if same_yinyang else "正印"
    return "未知"


def get_shishen_branch(dm_char, target_branch):
    """
    华山地支（实）十神生成法则 (The Branch Matrix - 虚实反转)
    地支“有形有实”。印星（生我）与食伤（我生）在地支层的标签发生反转。
    """
    dm_idx = TIANGAN.index(dm_char)
    target_idx = DIZHI.index(target_branch)
    
    # 物理阴阳归位
    same_yinyang = (YINYANG_TG[dm_idx] == YINYANG_DZ[target_idx])
    rel = _get_element_rel(dm_idx, target_idx, is_stem=False)
    
    if rel == 0: # 同我
        return "比肩" if same_yinyang else "劫财"
    elif rel == 1: # 我生 (地支反转: 同性伤官，异性食神)
        return "伤官" if same_yinyang else "食神"
    elif rel == 2: # 我克 (地支我克同天干，华山派：同性正财，异性偏财)
        return "正财" if same_yinyang else "偏财"
    elif rel == 3: # 克我
        return "七杀" if same_yinyang else "正官"
    elif rel == 4: # 生我 (地支反转: 同性正印，异性枭神)
        return "正印" if same_yinyang else "枭神"
    return "未知"


def get_hidden_stems(dm_char, branch):
    """返回藏干及其十神，如 [{'stem': '癸', 'shishen': '正财'}]"""
    hidden = HUASHAN_CANGGAN[branch]
    res = []
    for s in hidden:
        # 藏干论性质属“干”，用天干十神矩阵算
        res.append({"stem": s, "shishen": get_shishen_stem(dm_char, s)})
    return res


# --- [ 华山长生十二宫 ] ---

STAGES = ["长生", "沐浴", "冠带", "临官", "帝旺", "衰", "病", "死", "墓", "绝", "胎", "养"]
# 阳干顺排基点：甲->亥, 丙/戊->寅(戊土华山同水！故戊从戊->申！), 庚->巳, 壬->申
# 纠正：华山戊己土从水起：甲=亥, 丙=寅, 戊=申, 庚=巳, 壬=申
START_STAGE_YANG = {
    "甲": "亥", "丙": "寅", "戊": "申", "庚": "巳", "壬": "申"
}
# 阴干逆排基点：起于阳干死地，如乙木死在亥->乙长生在午
# 甲死在午->乙起午，丙死在酉->丁起酉，戊死在卯->己起卯，庚死在子->辛起子，壬死在卯->癸起卯
START_STAGE_YIN = {
    "乙": "午", "丁": "酉", "己": "卯", "辛": "子", "癸": "卯"
}

def get_life_stage(tg_char, dz_char):
    """
    获取长生十二宫
    阳干顺行，阴干逆行。注意戊己土的华山例外。
    """
    tg_idx = TIANGAN.index(tg_char)
    is_yang = (YINYANG_TG[tg_idx] == 1)
    
    start_point = START_STAGE_YANG[tg_char] if is_yang else START_STAGE_YIN[tg_char]
    start_idx = DIZHI.index(start_point)
    target_idx = DIZHI.index(dz_char)
    
    # 顺逆偏差计算
    if is_yang:
        offset = (target_idx - start_idx) % 12
    else:
        offset = (start_idx - target_idx) % 12
        
    return STAGES[offset]

# --- [ 旬空推算 ] ---
def get_xunkong(day_stem, day_branch):
    """
    由日柱推算旬空（六甲空亡）
    甲子旬空戌亥，甲戌旬空申酉，甲申旬空午未，甲午旬空辰巳，甲辰旬空寅卯，甲寅旬空子丑
    计算法：地支索引 - 天干索引，如果为负则+12，就是旬空首支
    """
    tg_idx = TIANGAN.index(day_stem)
    dz_idx = DIZHI.index(day_branch)
    start_vacant = (dz_idx - tg_idx) % 12
    if start_vacant < 0: start_vacant += 12
    
    # 因为天干差10位，补齐后的两位即为前面两支
    x_idx_1 = (start_vacant - 2) % 12
    x_idx_2 = (start_vacant - 1) % 12
    return [DIZHI[x_idx_1], DIZHI[x_idx_2]]


# --- [ 华山十八星煞 ] ---
def get_shensha(dm, branch, is_year=False, is_day=False, is_month=False, year_branch=None, day_branch=None, month_branch=None):
    """
    华山精简18星煞判断：
    返回命中所有的星煞列表
    """
    stars = []
    
    # 1. 贵人 (日干定) 甲戊庚牛羊，乙己鼠猴乡，丙丁猪鸡位，壬癸兔蛇藏，六辛逢虎马
    if (dm in "甲戊庚" and branch in "丑未") or \
       (dm in "乙己" and branch in "子申") or \
       (dm in "丙丁" and branch in "亥酉") or \
       (dm in "壬癸" and branch in "卯巳") or \
       (dm == "辛" and branch in "寅午"):
        stars.append("贵人")
        
    # 2. 食禄 (日干定，临官位) 甲禄在寅，乙禄在卯，丙戊在巳，丁己在午，庚在申，辛在酉，壬在亥，癸在子
    # 华山特例：戊己随水走？禄是建禄，还是按火？传统戊禄在巳，华山土随水，戊禄可能随壬禄即在亥？
    # 原著未明言土禄变更，我们按《华山八字》一般论断，十二长生的临官位置即为禄
    ls = get_life_stage(dm, branch)
    if ls == "临官":
        stars.append("食禄")
        
    # 3. 羊刃 (日干定，帝旺位)  一般阳干才论刃，阴干无论（但极少数用长生位），以帝旺标刃
    if ls == "帝旺" and dm in "甲丙戊庚壬": # 华山通常帝旺为刃
        stars.append("羊刃")
        
    # 4. 文昌 (日干定)：甲巳乙午丙戊申... 等同于食神建禄处。但查表可知：
    wc_map = {'甲':'巳','乙':'午','丙':'申','丁':'酉','戊':'申','己':'酉','庚':'亥','辛':'子','壬':'寅','癸':'卯'}
    if wc_map.get(dm) == branch:
        stars.append("文昌")
        
    # 5. 学堂 (日干长生位)
    if ls == "长生":
        stars.append("学堂")

    # 三合局索引定局(亥卯未、寅午戌、巳酉丑、申子辰)
    def in_tri_group(b, g_type):
        if g_type == "木": return b in "亥卯未"
        if g_type == "火": return b in "寅午戌"
        if g_type == "金": return b in "巳酉丑"
        if g_type == "水": return b in "申子辰"
        return False

    base_branches = []
    if year_branch: base_branches.append(year_branch)
    if day_branch: base_branches.append(day_branch)

    # 6. 驿马 (年/日支定)：三合局冲首支。如申子辰见寅
    # 7. 桃花/咸池 (年/日支定)：三合局沐浴支。如申子辰见酉
    # 8. 华盖 (日/月支定，或年)：三合局末支。如申子辰见辰
    # 9. 劫煞 (年/日/局定)：三合局长生前一位，如申子辰见巳
    # 10. 灾煞 (年/日定)：三合局临官前对冲位，如申子辰见午
    # 11. 将星 (日支定为主)：三合局子流，如申子辰见子
    for b_base in base_branches:
        if in_tri_group(b_base, "水"):  # 申子辰
            if branch == "寅" and "驿马" not in stars: stars.append("驿马")
            if branch == "酉" and "桃花" not in stars: stars.append("桃花")
            if branch == "辰" and "华盖" not in stars: stars.append("华盖")
            if branch == "巳" and "劫煞" not in stars: stars.append("劫煞")
            if branch == "午" and "灾煞" not in stars: stars.append("灾煞")
            if branch == "子" and "将星" not in stars: stars.append("将星")
        elif in_tri_group(b_base, "木"): # 亥卯未
            if branch == "巳" and "驿马" not in stars: stars.append("驿马")
            if branch == "子" and "桃花" not in stars: stars.append("桃花")
            if branch == "未" and "华盖" not in stars: stars.append("华盖")
            if branch == "申" and "劫煞" not in stars: stars.append("劫煞")
            if branch == "酉" and "灾煞" not in stars: stars.append("灾煞")
            if branch == "卯" and "将星" not in stars: stars.append("将星")
        elif in_tri_group(b_base, "火"): # 寅午戌
            if branch == "申" and "驿马" not in stars: stars.append("驿马")
            if branch == "卯" and "桃花" not in stars: stars.append("桃花")
            if branch == "戌" and "华盖" not in stars: stars.append("华盖")
            if branch == "亥" and "劫煞" not in stars: stars.append("劫煞")
            if branch == "子" and "灾煞" not in stars: stars.append("灾煞")
            if branch == "午" and "将星" not in stars: stars.append("将星")
        elif in_tri_group(b_base, "金"): # 巳酉丑
            if branch == "亥" and "驿马" not in stars: stars.append("驿马")
            if branch == "午" and "桃花" not in stars: stars.append("桃花")
            if branch == "丑" and "华盖" not in stars: stars.append("华盖")
            if branch == "寅" and "劫煞" not in stars: stars.append("劫煞")
            if branch == "卯" and "灾煞" not in stars: stars.append("灾煞")
            if branch == "酉" and "将星" not in stars: stars.append("将星")
            
    # 12. 孤辰寡宿 (生年支定)
    # 寅卯辰人，孤辰在巳，寡宿在丑...
    if year_branch:
        if year_branch in "亥子丑":
            if branch == "寅": stars.append("孤辰")
            if branch == "戌": stars.append("寡宿")
        elif year_branch in "寅卯辰":
            if branch == "巳": stars.append("孤辰")
            if branch == "丑": stars.append("寡宿")
        elif year_branch in "巳午未":
            if branch == "申": stars.append("孤辰")
            if branch == "辰": stars.append("寡宿")
        elif year_branch in "申酉戌":
            if branch == "亥": stars.append("孤辰")
            if branch == "未": stars.append("寡宿")
            
    # 13. 天医 (月支定) - 缺省月建前一位
    if month_branch:
        mb_idx = DIZHI.index(month_branch)
        if DIZHI[(mb_idx - 1) % 12] == branch:
            stars.append("天医")
            
    # 14. 天喜 (月支定) - 正月建逢戌等(春从辰对冲戌起逆推)
    # 春建寅->戌，卯->酉，辰->申，巳->未，午->午，未->巳...
    tx_map = {"寅":"戌","卯":"酉","辰":"申","巳":"未","午":"午","未":"巳","申":"辰","酉":"卯","戌":"寅","亥":"丑","子":"子","丑":"亥"}
    if month_branch and tx_map.get(month_branch) == branch:
        stars.append("天喜")
        
    # 15. 天罗地网：戍亥为天罗，辰巳为地网 (只粗略判地支)
    if branch in "辰巳": stars.append("天罗地网")
    if branch in "戌亥": stars.append("天罗地网")

    return stars

# --- [ 甲子纳音推算 ] ---
def get_nayin(tg, dz):
    """
    甲子纳音经典算法
    天干数: 甲乙1, 丙丁2, 戊己3, 庚辛4, 壬癸5
    地支数: 子午丑未1, 寅申卯酉2, 辰戌巳亥3
    和值对5取余，对应: 1木 2金 3水 4火 5/0土
    """
    tg_nums = {"甲":1,"乙":1, "丙":2,"丁":2, "戊":3,"己":3, "庚":4,"辛":4, "壬":5,"癸":5}
    dz_nums = {"子":1,"午":1, "丑":1,"未":1, "寅":2,"申":2, "卯":2,"酉":2, "辰":3,"戌":3, "巳":3,"亥":3}
    
    val = tg_nums[tg] + dz_nums[dz]
    rem = val % 5
    ny_wx = {1:"木", 2:"金", 3:"水", 4:"火", 0:"土"}[rem]
    
    # 这里的全表查阅也是一种办法，若为了准确度可直接查60纳音表
    # 这边为了保证不丢失花哨名称，简单贴一个常用映射表
    nayin_table = {
        "甲子":"海中金", "乙丑":"海中金", "丙寅":"炉中火", "丁卯":"炉中火", "戊辰":"大林木", "己巳":"大林木",
        "庚午":"路旁土", "辛未":"路旁土", "壬申":"剑锋金", "癸酉":"剑锋金", "甲戌":"山头火", "乙亥":"山头火",
        "丙子":"涧下水", "丁丑":"涧下水", "戊寅":"城墙土", "己卯":"城墙土", "庚辰":"白蜡金", "辛巳":"白蜡金",
        "壬午":"杨柳木", "癸未":"杨柳木", "甲申":"泉中水", "乙酉":"泉中水", "丙戌":"屋上土", "丁亥":"屋上土",
        "戊子":"霹雳火", "己丑":"霹雳火", "庚寅":"松柏木", "辛卯":"松柏木", "壬辰":"长流水", "癸巳":"长流水",
        "甲午":"沙中金", "乙未":"沙中金", "丙申":"山下火", "丁酉":"山下火", "戊戌":"平地木", "己亥":"平地木",
        "庚子":"壁上土", "辛丑":"壁上土", "壬寅":"金箔金", "癸卯":"金箔金", "甲辰":"佛灯火", "乙巳":"佛灯火",
        "丙午":"天河水", "丁未":"天河水", "戊申":"大驿土", "己酉":"大驿土", "庚戌":"钗钏金", "辛亥":"钗钏金",
        "壬子":"桑松木", "癸丑":"桑松木", "甲寅":"大溪水", "乙卯":"大溪水", "丙辰":"沙中土", "丁巳":"沙中土",
        "戊午":"天上火", "己未":"天上火", "庚申":"石榴木", "辛酉":"石榴木", "壬戌":"大海水", "癸亥":"大海水"
    }
    return nayin_table.get(tg+dz, f"纳音({ny_wx})")
