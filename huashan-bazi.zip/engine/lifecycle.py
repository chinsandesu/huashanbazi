# lifecycle.py
import datetime
from huashan_core import TIANGAN, DIZHI, WUXING_TG, YINYANG_TG

def get_next_gz(tg, dz, step=1):
    """顺推或逆推干支（step为+1则顺，-1则逆）"""
    tg_idx = (TIANGAN.index(tg) + step) % 10
    dz_idx = (DIZHI.index(dz) + step) % 12
    return TIANGAN[tg_idx], DIZHI[dz_idx]

def get_yun_direction(year_stem, gender):
    """
    大运/小运的顺逆规则
    阳男阴女顺行，阴男阳女逆行
    阳性天干：甲丙戊庚壬
    """
    is_yang_year = YINYANG_TG[TIANGAN.index(year_stem)] == 1
    if (is_yang_year and gender.upper() == 'M') or (not is_yang_year and gender.upper() == 'F'):
        return 1 # Forward
    return -1 # Backward


def calc_dayun_age(solar_date, next_jieqi_date, prev_jieqi_date, direction):
    """
    起运岁数精确求解
    顺推：出生日至**未来**节令的天数
    逆推：出生日至**过去**节令的天数
    换算逻辑：3天=1岁, 1天=4个月, 1小时=5天
    返回值：包含岁数浮点和字符串表述的元组
    """
    if direction == 1:
        delta = next_jieqi_date - solar_date
    else:
        delta = solar_date - prev_jieqi_date
        
    total_seconds = delta.total_seconds()
    days = int(total_seconds // 86400)
    hours = int((total_seconds % 86400) // 3600)
    
    # 公式
    age_years = days // 3
    leftover_days = days % 3
    age_months = leftover_days * 4 + (hours * 5) // 30
    
    # 小数化以便于逻辑比对
    exact_age = age_years + age_months / 12.0
    desc = f"{age_years}岁{age_months}个月"
    return exact_age, desc


def generate_dayun(month_stem, month_branch, direction, start_age, current_age):
    """
    生成当前的大运柱
    """
    # 每柱管10年
    idx = int((current_age - start_age) // 10)
    if idx < 0:
        return None, "未交大运" # 还未起运，一般看小运
        
    # 距离月令跨越了 idx+1 步
    steps = (idx + 1) * direction
    tg, dz = get_next_gz(month_stem, month_branch, steps)
    
    start_y = start_age + idx * 10
    end_y = start_y + 9
    return (tg, dz), f"{start_y:.1f}-{end_y:.1f}岁"


def generate_xiaoyun(hour_stem, hour_branch, direction, birth_date, current_date):
    """
    华山小运推演：以时柱为基底，出生起转，每年公历生日交脱！
    """
    # 计算当前经历的完整年数（过了几次生日）
    age_years = current_date.year - birth_date.year
    # 判断当年是否已经过了生日
    passed_birthday_this_year = (current_date.month > birth_date.month) or \
                                (current_date.month == birth_date.month and current_date.day >= birth_date.day)
                                
    steps = age_years if passed_birthday_this_year else max(0, age_years - 1)
    
    # 小运也是排柱的延伸
    tg, dz = get_next_gz(hour_stem, hour_branch, (steps + 1) * direction)
    return tg, dz

def generate_liunian(sxtwl_day):
    """
    流年直接依托于 sxtwl 当前日期的年份天干地支
    流年的切分点完全由立春界定。sxtwl.fromSolar(y,m,d) 的 getYearGZ() 已经内置了立春换年的逻辑。
    """
    ygz = sxtwl_day.getYearGZ()
    tg = TIANGAN[ygz.tg]
    dz = DIZHI[ygz.dz]
    return tg, dz

def get_lichun_date(year):
    import sxtwl
    for d in range(3, 6):
        try:
            day = sxtwl.fromSolar(year, 2, d)
            if day.hasJieQi() and day.getJieQi() == 3:
                return datetime.datetime(year, 2, d)
        except: pass
    return datetime.datetime(year, 2, 4)

def analyze_current_year(target_year, birth_date, hour_stem, hour_branch, year_stem, gender):
    """
    三维时空算法：基于自然年(西历)、立春、公历生日切割的三段流年小运互搏
    """
    from huashan_core import get_shishen_stem
    import sxtwl
    
    lichun_date = get_lichun_date(target_year)
    b_month, b_day = birth_date.month, birth_date.day
    
    # 这一年的生日 (如果出生在闰月29，此处简单回落到28处理)
    if b_month == 2 and b_day == 29:
        try:
            curr_bday = datetime.datetime(target_year, 2, 29)
        except ValueError:
            curr_bday = datetime.datetime(target_year, 2, 28)
    else:
        curr_bday = datetime.datetime(target_year, b_month, b_day)
    
    dir_val = get_yun_direction(year_stem, gender)
    
    xiaoyun_before = generate_xiaoyun(hour_stem, hour_branch, dir_val, birth_date, curr_bday - datetime.timedelta(days=1))
    xiaoyun_after = generate_xiaoyun(hour_stem, hour_branch, dir_val, birth_date, curr_bday)
    
    ln_before = generate_liunian(sxtwl.fromSolar(target_year, 2, 1)) # 立春前是去年的太岁
    ln_after = generate_liunian(sxtwl.fromSolar(target_year, 2, 15)) # 立春后是今年的太岁

    segments = []
    
    if curr_bday < lichun_date:
        rel1 = get_shishen_stem(ln_before[0], xiaoyun_before[0])
        segments.append({
            "Phase": f"{target_year}-01-01 to {(curr_bday - datetime.timedelta(days=1)).strftime('%m-%d')} (Pre-Birthday)",
            "Logic": "OldYear_OldLuck",
            "LiuNian": list(ln_before), "XiaoYun": list(xiaoyun_before), 
            "God": f"{ln_before[0]}遇{xiaoyun_before[0]} ({rel1})"
        })
        rel2 = get_shishen_stem(ln_before[0], xiaoyun_after[0])
        segments.append({
            "Phase": f"{curr_bday.strftime('%m-%d')} to {(lichun_date - datetime.timedelta(days=1)).strftime('%m-%d')} (Inter-Period)",
            "Logic": "OldYear_NewLuck",
            "LiuNian": list(ln_before), "XiaoYun": list(xiaoyun_after),
            "God": f"{ln_before[0]}遇{xiaoyun_after[0]} ({rel2})"
        })
        rel3 = get_shishen_stem(ln_after[0], xiaoyun_after[0])
        segments.append({
            "Phase": f"{lichun_date.strftime('%m-%d')} to 12-31 (New Year&Luck)",
            "Logic": "NewYear_NewLuck",
            "LiuNian": list(ln_after), "XiaoYun": list(xiaoyun_after),
            "God": f"{ln_after[0]}遇{xiaoyun_after[0]} ({rel3})"
        })
    else:
        rel1 = get_shishen_stem(ln_before[0], xiaoyun_before[0])
        segments.append({
            "Phase": f"{target_year}-01-01 to {(lichun_date - datetime.timedelta(days=1)).strftime('%m-%d')} (Pre-Spring)",
            "Logic": "OldYear_OldLuck",
            "LiuNian": list(ln_before), "XiaoYun": list(xiaoyun_before),
             "God": f"{ln_before[0]}遇{xiaoyun_before[0]} ({rel1})"
        })
        rel2 = get_shishen_stem(ln_after[0], xiaoyun_before[0])
        segments.append({
            "Phase": f"{lichun_date.strftime('%m-%d')} to {(curr_bday - datetime.timedelta(days=1)).strftime('%m-%d')} (BirthdayGap)",
            "Logic": "NewYear_OldLuck",
            "LiuNian": list(ln_after), "XiaoYun": list(xiaoyun_before),
            "God": f"{ln_after[0]}遇{xiaoyun_before[0]} ({rel2})"
        })
        rel3 = get_shishen_stem(ln_after[0], xiaoyun_after[0])
        segments.append({
            "Phase": f"{curr_bday.strftime('%m-%d')} to 12-31 (Post-Birthday)",
            "Logic": "NewYear_NewLuck",
            "LiuNian": list(ln_after), "XiaoYun": list(xiaoyun_after),
            "God": f"{ln_after[0]}遇{xiaoyun_after[0]} ({rel3})"
        })
        
    return {
        "Year": f"{target_year} ({ln_after[0]}{ln_after[1]})",
        "AnnualPhases": segments
    }

def generate_liuyue(year_stem):
    """
    五虎遁推算当年十二个月的流月干支（立春起算为正月寅月）
    甲己之年丙作首，乙庚之年戊为头
    丙辛之岁寻庚上，丁壬壬寅顺水流
    若问戊癸何处起，甲寅之上好追求
    """
    from huashan_core import TIANGAN, DIZHI
    dz_start = 2 # 寅月为正月索引
    tg_start_map = {"甲": "丙", "己": "丙", 
                    "乙": "戊", "庚": "戊",
                    "丙": "庚", "辛": "庚",
                    "丁": "壬", "壬": "壬",
                    "戊": "甲", "癸": "甲"}
    
    first_month_tg = tg_start_map[year_stem]
    tg_start_idx = TIANGAN.index(first_month_tg)
    
    months = []
    # 春夏秋冬按十二地支顺排
    for step in range(12):
        tg = TIANGAN[(tg_start_idx + step) % 10]
        dz = DIZHI[(dz_start + step) % 12]
        months.append(f"{tg}{dz}")
        
    return months


def get_dayun_map(month_stem, month_branch, direction, start_age, birth_year):
    """
    生成终极四维大运盘（返回最近的3个大运，由于 CLI 控制台空间，太多不宜直接打印全量大运，这里限制输出）
    """
    from huashan_core import TIANGAN, DIZHI
    import sxtwl

    dayun_map = []
    current_year = datetime.datetime.now().year
    
    # 算一下当下的岁数所在的大运档位
    current_age = current_year - birth_year
    current_idx = int((current_age - start_age) // 10)
    current_idx = max(0, current_idx)

    # 我们输出涵盖当下的三个大运（前一个，现行的，下一个）
    start_point = max(0, current_idx - 1)
    end_point = start_point + 2
    
    for idx in range(start_point, end_point + 1):
        steps = (idx + 1) * direction
        tg, dz = get_next_gz(month_stem, month_branch, steps)
        d_start_age = start_age + idx * 10
        d_end_age = d_start_age + 9
        
        # 这个大运所覆盖的公历年份区间
        y_start = int(birth_year + d_start_age)
        y_end = int(birth_year + d_end_age)
        
        years_info = []
        for y in range(y_start, y_end + 1):
            # 获取该年的干支（取当年年中某一天来提取流年太岁，如7月1日）
            ygz = sxtwl.fromSolar(y, 7, 1).getYearGZ()
            year_tg = TIANGAN[ygz.tg]
            year_dz = DIZHI[ygz.dz]
            
            years_info.append({
                "LiuNian": f"{y} ({year_tg}{year_dz})",
                "LiuYue": generate_liuyue(year_tg)
            })
            
        dayun_map.append({
            "AgeRange": f"{d_start_age:.1f} - {d_end_age:.1f}",
            "DaYun": [tg, dz],
            "Years": years_info
        })
        
    return dayun_map
